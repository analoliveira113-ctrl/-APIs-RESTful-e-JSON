const express = require('express');
const app = express();

app.use(express.json());


// =========================
// FUNÇÃO PARA GERAR ID SEGURO (PRODUTOS)
// =========================
function gerarNovoId(lista) {
    if (lista.length === 0) return 1;
    return Math.max(...lista.map(item => item.id)) + 1;
}


// =========================
// ARRAY DE CATEGORIAS
// =========================
let categorias = [
    { nome: "Sorvetes" },
    { nome: "Milkshakes" },
    { nome: "Picolés" },
    { nome: "Açaís" },
    { nome: "Extras" }
];


// =========================
// ARRAY DE PRODUTOS
// =========================
let produtos = [

    [
  // Sorvetes
  { id: 1, categoria: "Sorvetes", nome: "Laços de Baunilha", preco: 29.90 },
  { id: 2, categoria: "Sorvetes", nome: "Laços de Chocolate", preco: 29.90 },
  { id: 3, categoria: "Sorvetes", nome: "Laços de Morango", preco: 29.90 },
  { id: 4, categoria: "Sorvetes", nome: "Laços Tropicais", preco: 15.00 },
  { id: 5, categoria: "Sorvetes", nome: "Laços do Verão", preco: 120.00 },
  { id: 6, categoria: "Sorvetes", nome: "Laços de Ouro", preco: 45.00 },
  { id: 7, categoria: "Sorvetes", nome: "Laços Trufados", preco: 45.00 },
  { id: 8, categoria: "Sorvetes", nome: "Laços Romeu e Julieta", preco: 45.00 },

  // Milkshakes 
  { id: 9, categoria: "Milkshakes", nome: "Laços de Chocolate Cremoso", preco: 18.00 },
  { id: 10, categoria: "Milkshakes", nome: "Laços de Baunilha Doce", preco: 18.00 },
  { id: 11, categoria: "Milkshakes", nome: "Laço Rosa de Morango", preco: 18.00 },
  { id: 12, categoria: "Milkshakes", nome: "Laço Tropical Gelado", preco: 18.00 },
  { id: 13, categoria: "Milkshakes", nome: "Laço Trufado Supremo", preco: 22.00 },
  { id: 14, categoria: "Milkshakes", nome: "Laços de Avelã Encantada", preco: 22.00 },
  { id: 15, categoria: "Milkshakes", nome: "Laços de Cookies & Amor", preco: 22.00 },

  // Extras
  { id: 16, categoria: "Extras", nome: "Borda recheada", preco: 4.00 },
  { id: 17, categoria: "Extras", nome: "Chantilly extra", preco: 3.00 },
  { id: 18, categoria: "Extras", nome: "Calda extra", preco: 3.00 },
  { id: 19, categoria: "Extras", nome: "Topping especial", preco: 4.00 },

  // Picolés 
  { id: 20, categoria: "Picolés", nome: "Lacinho de Verão", preco: 6.50 },
  { id: 21, categoria: "Picolés", nome: "Fita Tropical", preco: 6.50 },
  { id: 22, categoria: "Picolés", nome: "Laço Cítrico Encantado", preco: 6.50 },
  { id: 23, categoria: "Picolés", nome: "Nó de Uva Doceo", preco: 6.50 },
  { id: 24, categoria: "Picolés", nome: "Volta do Laço", preco: 6.50 },
  { id: 25, categoria: "Picolés", nome: "Laço de Nuvem", preco: 8.00 },
  { id: 26, categoria: "Picolés", nome: "Fita Rosada", preco: 8.00 },
  { id: 27, categoria: "Picolés", nome: "Nó de Chocolate Belga", preco: 8.00 },
  { id: 28, categoria: "Picolés", nome: "Voltinhas de Avelã", preco: 8.00 },
  { id: 29, categoria: "Picolés", nome: "Laço Surpresa Doce", preco: 10.00 },
  { id: 30, categoria: "Picolés", nome: "Enlace Romeu", preco: 10.00 },
  { id: 31, categoria: "Picolés", nome: "Duplo Laço Trufado", preco: 10.00 },

  // Açaí 
  { id: 32, categoria: "Açaí", nome: "Açaí 300ml", preco: 12.00 },
  { id: 33, categoria: "Açaí", nome: "Açaí 400ml", preco: 16.00 },
  { id: 34, categoria: "Açaí", nome: "Açaí 500ml", preco: 20.00 },
  { id: 35, categoria: "Açaí", nome: "Laço Roxo Tradicional", preco: 24.00 },
  { id: 36, categoria: "Açaí", nome: "Laço Doce Encantado", preco: 24.00 },
  { id: 37, categoria: "Açaí", nome: "Laço Trufado Tropical", preco: 24.00 },
  { id: 38, categoria: "Açaí", nome: "Laço Praiano", preco: 24.00 },
  { id: 39, categoria: "Açaí", nome: "Nó Energético", preco: 24.00 },
  { id: 40, categoria: "Açaí", nome: "Taça Grande Laço Supremo", preco: 30.00 },
  { id: 41, categoria: "Açaí", nome: "Taça Duplo Enlace", preco: 30.00 }
]
];


// =====================================================
// =================== PRODUTOS ========================
// =====================================================

// GET todos
app.get('/produtos', (req, res) => {
    res.json(produtos);
});

// GET por ID
app.get('/produtos/:id', (req, res) => {
    const id = Number(req.params.id);
    const produto = produtos.find(p => p.id === id);

    if (!produto) {
        return res.status(404).json({ error: "Produto não encontrado" });
    }

    res.json(produto);
});

// POST
app.post('/produtos', (req, res) => {
    const { nome, preco, categoria } = req.body;

    if (!nome || preco == null || !categoria) {
        return res.status(400).json({ error: "Nome, preço e categoria são obrigatórios" });
    }

    const categoriaExiste = categorias.find(c => c.nome === categoria);
    if (!categoriaExiste) {
        return res.status(400).json({ error: "Categoria não existe" });
    }

    const novoProduto = {
        id: gerarNovoId(produtos),
        nome,
        preco,
        categoria
    };

    produtos.push(novoProduto);
    res.status(201).json(novoProduto);
});

// PUT por ID
app.put('/produtos/:id', (req, res) => {
    const id = Number(req.params.id);
    const { nome, preco, categoria } = req.body;

    const index = produtos.findIndex(p => p.id === id);
    if (index === -1) {
        return res.status(404).json({ error: "Produto não encontrado" });
    }

    if (categoria) {
        const categoriaExiste = categorias.find(c => c.nome === categoria);
        if (!categoriaExiste) {
            return res.status(400).json({ error: "Categoria não existe" });
        }
    }

    produtos[index] = {
        ...produtos[index],
        nome: nome ?? produtos[index].nome,
        preco: preco ?? produtos[index].preco,
        categoria: categoria ?? produtos[index].categoria
    };

    res.json(produtos[index]);
});

// DELETE por ID
app.delete('/produtos/:id', (req, res) => {
    const id = Number(req.params.id);
    const index = produtos.findIndex(p => p.id === id);

    if (index === -1) {
        return res.status(404).json({ error: "Produto não encontrado" });
    }

    const removido = produtos.splice(index, 1)[0];
    res.json({ mensagem: "Produto removido", produto: removido });
});


// =====================================================
// =================== CATEGORIAS (SÓ POR NOME) ========
// =====================================================

// GET todas
app.get('/categorias', (req, res) => {
    res.json(categorias);
});

// GET por NOME
app.get('/categorias/:nome', (req, res) => {
    const nome = req.params.nome.toLowerCase();

    const categoria = categorias.find(c =>
        c.nome.toLowerCase() === nome
    );

    if (!categoria) {
        return res.status(404).json({ error: "Categoria não encontrada" });
    }

    res.json(categoria);
});

// POST
app.post('/categorias', (req, res) => {
    const { nome } = req.body;

    if (!nome) {
        return res.status(400).json({ error: "Nome é obrigatório" });
    }

    categorias.push({ nome });
    res.status(201).json({ nome });
});

// PUT por NOME
app.put('/categorias/:nome', (req, res) => {
    const nome = req.params.nome.toLowerCase();
    const { novoNome } = req.body;

    const categoria = categorias.find(c =>
        c.nome.toLowerCase() === nome
    );

    if (!categoria) {
        return res.status(404).json({ error: "Categoria não encontrada" });
    }

    categoria.nome = novoNome ?? categoria.nome;

    res.json(categoria);
});

// DELETE por NOME
app.delete('/categorias/:nome', (req, res) => {
    const nome = req.params.nome.toLowerCase();

    const index = categorias.findIndex(c =>
        c.nome.toLowerCase() === nome
    );

    if (index === -1) {
        return res.status(404).json({ error: "Categoria não encontrada" });
    }

    const removida = categorias.splice(index, 1)[0];

    // Remove produtos da categoria
    produtos = produtos.filter(p =>
        p.categoria.toLowerCase() !== nome
    );

    res.json({ mensagem: "Categoria removida", categoria: removida });
});


// =====================================================
// FILTRAR PRODUTOS POR NOME DA CATEGORIA
// =====================================================

app.get('/produtos/categoria/:nome', (req, res) => {
    const nome = req.params.nome.toLowerCase();

    const filtrados = produtos.filter(p =>
        p.categoria.toLowerCase() === nome
    );

    res.json(filtrados);
});


// =========================
// INICIAR SERVIDOR
// =========================
app.listen(3000, () => {
    console.log("Servidor rodando em http://localhost:3000");
});